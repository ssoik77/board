package com.jspDaoDto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Db {

	static public String DB_JDBC_DRIVER_PACKAGE_PATH = "com.mysql.cj.jdbc.Driver";	
	static public String DB_NAME = "my_cat";
	static public String DB_URL_MYSQL = "jdbc:mysql://localhost:3306/"+DB_NAME;
	static public String DB_URL = DB_URL_MYSQL;
	static public String DB_ID = "root";
	static public String DB_PW = "root";
	
	static public String TABLE_PS_BOARD_FREE = "PS_BOARD_FREE";
	public Connection con = null;
	public Statement st = null;
	
	
	public void connect() throws Exception {

		Class.forName(DB_JDBC_DRIVER_PACKAGE_PATH);
		con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
		st = con.createStatement();

	}

	public void close() throws Exception {

		if (st != null)
			st.close();
		if (con != null)
			con.close();

	}
	
	
}
