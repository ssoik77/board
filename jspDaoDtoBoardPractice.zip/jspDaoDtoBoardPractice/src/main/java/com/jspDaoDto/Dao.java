package com.jspDaoDto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao extends Db {

	public ArrayList<Dto> list(String p) {

		ArrayList<Dto> posts = new ArrayList<Dto>();

		try {
			connect();

			int page = (Integer.parseInt(p)-1) * 3;
			
			String sql = String.format("select * from %s order by B_NO desc limit %s,3;", TABLE_PS_BOARD_FREE, page);
			ResultSet re = st.executeQuery(sql);

			while (re.next()) {
				posts.add(new Dto(re.getString("B_NO"), re.getString("B_TITLE"), re.getString("B_ID"),
						re.getString("B_DATETIME"), re.getString("B_HIT"), re.getString("B_TEXT"),
						re.getString("B_REPLY_COUNT"), re.getString("B_REPLY_ORI")));
			}
			close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return posts;

	}

	public ArrayList<Dto> list_serch(String w, String p){
		
		ArrayList<Dto> post = new ArrayList<Dto>();
		
		try {
			
			connect();
			
			String sql = String.format("select * from %s where B_TITLE like '%%%s%%' order by B_NO desc limit %s,3;",TABLE_PS_BOARD_FREE,w,p );
			
			ResultSet re = st.executeQuery(sql);
			
			while(re.next()) {
				
				post.add(new Dto(
						re.getString("B_NO"),
						re.getString("B_TITLE"),
						re.getString("B_ID"),
						re.getString("B_DATETIME"),
						re.getString("B_HIT"),
						re.getString("B_TEXT"),
						re.getString("B_REPLY_COUNT"),
						re.getString("B_REPLY_ORI")
						)
						);
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return post;
		
		
	}
	
	
	
	public void write(Dto a) {

		try {
			connect();

			String sql = String.format("insert into %s(B_TITLE, B_ID, B_TEXT) value('%s', '%s', '%s')",
					TABLE_PS_BOARD_FREE, a.title, a.id, a.text);
			st.executeUpdate(sql);

			close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Dto read(String no) {
		Dto post = null;
		try {

			connect();

			String sql = String.format("select * from %s where B_NO = %s", TABLE_PS_BOARD_FREE, no);
			ResultSet rs = st.executeQuery(sql);

			rs.next();
			post = new Dto(rs.getString("B_NO"), rs.getString("B_TITLE"), rs.getString("B_ID"),
					rs.getString("B_DATETIME"), rs.getString("B_HIT"), rs.getString("B_TEXT"),
					rs.getString("B_REPLY_COUNT"), rs.getString("B_REPLY_ORI"));

			close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return post;
	}

	public void delete(String no) {

		try {

			connect();

			String sql = String.format("delete from %s where B_NO = %s", Db.TABLE_PS_BOARD_FREE, no);

			st.executeUpdate(sql);

			close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void edit(Dto d, String no) {

		try {

			connect();

			String sql = String.format("update %s set B_TITLE = %s, B_TEXT = %s where B_NO = %s ;",
					Db.TABLE_PS_BOARD_FREE, d.title, d.text, no);
			st.executeUpdate(sql);

			close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public int page_count() {

		int PageCount = 0;

		try {
			connect();

			String sql = String.format("select count(*) from %s;", TABLE_PS_BOARD_FREE);

			ResultSet result = st.executeQuery(sql);
			
			result.next();
			
			int count = result.getInt("count(*)");
			int elsecount = count % 3;
			if(elsecount == 0) {
				PageCount = count/3;
				
			}else {
				PageCount = count/3 + 1;
			}
			

			close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return PageCount;
	}
	
	public int serch_page_count(String w) {
		
		int PageCount = 0;
		
		try {
			connect();
			
			String sql = String.format("select count(*) from %s where B_TITLE like '%%%s%%';", TABLE_PS_BOARD_FREE,w);
			
			ResultSet result = st.executeQuery(sql);
			
			result.next();
			
			int count = result.getInt("count(*)");
			int elsecount = count % 3;
			if(elsecount == 0) {
				PageCount = count/3;
				
			}else {
				PageCount = count/3 + 1;
			}
			
			
			close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return PageCount;
	}

}
